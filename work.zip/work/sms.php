
<!DOCTYPE HTML>
<html lang="en-US">

<?php include "head.php"; ?>

<body>
	
<?php include "nav2.php"; ?> 



<!--==================================================-->
<!-- Start Toptech Breadcumb Area -->
<!--==================================================-->
<div class="breadcumb-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="breadcumb-content">
					<h4>Service Details </h4>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li>></li>
						<li>Service Details </li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Breadcumb Area -->
<!--==================================================-->



<!--==================================================-->
<!-- Strat Toptech Service Details Area -->
<!--==================================================-->
<div class="services-details-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<div class="row">
					<div class="col-lg-12">
						<div class="services-details-thumb">
							<img src="assets/images/servies/sms.jpg" alt="">
						</div>
						<div class="services-details-content">
							<h4 class="services-details-title">Bulk SMS</h4>
							<h3 class="services-details-title">Nimatooz Bulk SMS</h3>

							<p class="services-details-desc">Nimatooz Bulk sms is the most familiar way to reach the customers. In the period, we have appeared as the leading Bulk SMS provider with a registered brand name Nimatooz Bulk SMS.  </p>

							<p class="services-details-desc">We’ve used industry specific best practices to satisfy our clients. We believe in complete transparency. Send bulk sms messaging online in real time and get accurate delivery reports. Nimatooz Bulk SMS provides you with a simple platform to set up a sms campaign quickly.</p>
						</div>
						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="service-details-icon-box">
									<div class="service-details-icon-thumb">
										<img src="assets/images/service-inner/services-details-icon-1.png" alt="">
									</div>
									<div class="service-details-box-content">
										<h4>Whatsapp SMS Marketing</h4>
										<p>Nimatooz Whatsapp SMS is the most common method of communicating with customers. During this time.</p>
									</div>
								</div>
							</div>							
							<div class="col-lg-6 col-md-6">
								<div class="service-details-icon-box">
									<div class="service-details-icon-thumb">
										<img src="assets/images/service-inner/services-details-icon-2.png" alt="">
									</div>
									<div class="service-details-box-content">
										<h4>Bulk SMS Marketing</h4>
										<p> Nimatooz Whatsapp SMS offers a simple platform for quickly launching an SMS campaign.</p>
									</div>
								</div>
							</div>
						</div>
						

						<h4 class="services-details-title">What the Benifits?</h4>
						<p class="services-details-desc">No more waiting for IT/development teams to host the file or create a webpage for your developing. Just upload and send via Textlocal. Reach of Bulk gives high accuracy to reach the customer. The reach for your attachments is probably higher than email when you share them through SMS. </p>

						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="single-benifits-box">
									<div class="benifits-thumb">
										<img src="assets/images/service-inner/services-details-benifis-thumb-1.png" alt="">
									</div>
									<div class="benifits-content">
										<h4>Analysis And Planning.</h4>
										<ul>
											<li><i class="bi bi-check2"></i>Easily receive SMS</li>
											<li><i class="bi bi-check2"></i>High level quality confidence.</li>
										</ul>
									</div>
								</div>
							</div>							
							<div class="col-lg-6 col-md-6">
								<div class="single-benifits-box">
									<div class="benifits-thumb">
										<img src="assets/images/service-inner/services-details-benifis-thumb-2.png" alt="">
									</div>
									<div class="benifits-content">
										<h4>Design & Development.</h4>
										<ul>
											<li><i class="bi bi-check2"></i>Long codes given by Textlocal</li>
											<li><i class="bi bi-check2"></i>Agile development technologies.</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="row">
					<div class="col-lg-12">
						<div class="widget-sidber">
							<div class="widget-sidber-content">
								<h4>Categories</h4>
							</div>
							<div class="widget-category">
								<ul>
									<li><a href="web-dev.php"><img src="assets/images/service-inner/category-icon.png" alt="">Web Development<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="mobile-dev.php"><img src="assets/images/service-inner/category-icon.png" alt="">App Development<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="web-design.php"><img src="assets/images/service-inner/category-icon.png" alt="">Web Design<i class="bi bi-arrow-right"></i></a></li>								
									<li><a href="digital-marketing.php"><img src="assets/images/service-inner/category-icon.png" alt="">Digital Marketing<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="seo.php"><img src="assets/images/service-inner/category-icon.png" alt="">SEO Marketing<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="sms.php"><img src="assets/images/service-inner/category-icon.png" alt="">Bulk SMS<i class="bi bi-arrow-right"></i></a></li>
								</ul>
							</div>
						</div>						
						<div class="widget-sidber">
							<div class="widget-sidber-content">
								<h4>Downloads</h4>
							</div>
							<div class="widget-sidber-download-button">
								<a href="assets/nsm-brochure.pdf" download><i class="bi bi-file-earmark-pdf"></i>Service Report<span><i class="bi bi-download"></i></span></a>

								<a class="active" href="assets/nsm-brochure.pdf" download><i class="bi bi-file-earmark-pdf"></i>Download Lists<span><i class="bi bi-download"></i></span></a>
							</div>
						</div>
						<div class="widget-sidber-contact-box">
							<div class="widget-sidber-contact">
								<img src="assets/images/inner-images/sidber-cont-icon.png" alt="">
							</div>
							<p class="widget-sidber-contact-text">Call Us Anytime</p>
							<h3 class="widget-sidber-contact-number"><a href="tel:+917708504776">+91 77085 04776</a></h3>
							<a class="widget-sidber-contact-gmail text-white" href="mailto:hello@smilemobility.in" target="_blank"><i class="bi bi-envelope-fill"></i> mailto:hello@smilemobility.in</a>
							<div class="widget-sidber-contact-btn">
								<a href="contact.php">Contact Us <i class="bi bi-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Service Details Area -->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Brand Area Style Two-->
<!--==================================================-->
<div class="brand-area style-two">
	<div class="container">
		<div class="row">
			<div class="brand-list-1 owl-carousel">
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_1.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_2.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_3.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_5.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_6 .png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_9  .png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Brand Area Style Two-->
<!--==================================================-->


<?php include "footer.php"; ?>




<!--==================================================-->
<!-- Start Toptech Scroll Up-->
<!--==================================================-->
<div class="prgoress_indicator active-progress">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
          <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 212.78;"></path>
        </svg>
 </div>
<!--==================================================-->
<!-- End Toptech Scroll Up-->
<!--==================================================-->

	<!-- jquery js -->
	<script src="assets/js/vendor/jquery-3.6.2.min.js"></script>
	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- carousel js -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- wow js -->
	<script src="assets/js/wow.js"></script>
	<!-- ajax-mail js -->
	<script src="assets/js/ajax-mail.js"></script>
	<!-- imagesloaded js -->
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>
	<!-- venobox js -->
	<script src="venobox/venobox.js"></script>
	<!--  animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- venobox min js -->
	<script src="venobox/venobox.min.js"></script>
	<!-- jquery meanmenu js -->
	<script src="assets/js/jquery.meanmenu.js"></script>
	<!-- theme js -->
	<script src="assets/js/theme.js"></script>
	<!-- Cousom carousel js -->
	<script src="assets/js/coustom-carousel.js"></script>
	<script src="assets/js/scroll-up.js"></script>

</body>
</html>