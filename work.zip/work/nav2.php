
<!--==================================================-->
<!-- Start Toptech Header Area Inner Style-->
<!--==================================================-->
<div class="header-area inner-style" id="sticky-header" >
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-3">
				<div class="header-logo">
					<a href="index.html"><img src="assets/images/logo-.png" alt="logo"></a>
				</div>
			</div>
			<div class="col-lg-9">
				<div class="header-menu">
					<ul>
						<li class="menu-item-has-children"><a href="index.php">Home</a>
                           
						</li>
						<li class="menu-item-has-children"><a href="about.php">About</a>
                           
						</li>
						<li class="menu-item-has-children"><a href="service.php">Service<i class="fas fa-chevron-down"></i></a>
                           <ul class="sub-menu">
						   <li><a href="mobile-dev.php">Mobile App Development</a></li>
                           	   <li><a href="web-dev.php">Web App Development</a></li>
                           	   <li><a href="web-design.php">Web Design</a></li>
                           	   <li><a href="digital-marketing.php">Digital Marketing</a></li>
								  <li><a href="seo.php">SEO Marketing</a></li>                           	  
                           	   <li><a href="sms.php">Bulk SMS</a></li> 
                           </ul>
						</li>
						
						<li><a href="contact.php">Contact</a></li>
					</ul>
					<div class="header-button">
						<a href="contact.php">Get A Quote</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Header Area Inner Style-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Main Menu Area -->
<!--==================================================-->
<div class="mobile-menu-area sticky d-sm-block d-md-block d-lg-none ">
	<div class="mobile-menu">
		<nav class="header-menu">
			<ul class="nav_scroll">
				<li class="menu-item-has-children"><a href="index.php">Home</a>
                  
				</li>
				<li class="menu-item-has-children"><a href="about.php">About</a>
                
				</li>
				<li class="menu-item-has-children"><a href="service.php">Service</a>
                   <ul class="sub-menu">
                   	  		   <li><a href="mobile-dev.php">Mobile App Development</a></li>
                           	   <li><a href="web-dev.php">Web App Development</a></li>
                           	   <li><a href="web-design.php">Web Design</a></li>
                           	   <li><a href="digital-marketing.php">Digital Marketing</a></li> 
								  <li><a href="seo.php">SEO Marketing</a></li>                           	  
                           	   <li><a href="sms.php">Bulk SMS</a></li>
                           </ul>
						
				</li>
				<li><a href="contact.php">Contact</a></li>
			</ul>
		</nav>
	</div>
</div>
<!--==================================================-->
<!-- End Main Menu Area -->
<!--==================================================-->