
<!DOCTYPE HTML>
<html lang="en-US">

<?php include "head.php"; ?>

<body>
	
<?php include "nav2.php"; ?> 

<!--==================================================-->
<!-- Start Toptech Breadcumb Area -->
<!--==================================================-->
<div class="breadcumb-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="breadcumb-content">
					<h4>Contact Us</h4>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li>></li>
						<li>Contact Us</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Breadcumb Area -->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Contact Style Three-->
<!--==================================================-->
<div class="contact-area style-three inner">
	<div class="container">
		<div class="row add-white-bg align-items-center">
			<div class="col-lg-8 col-md-12">
                <div class="single-contact-box">
                	<div class="contact-contetn">
                		<h4>Write to Us Anytime</h4>
                	</div>
                	<form action="#">
                		<div class="row">
                			<div class="col-lg-6">
                				<div class="single-input-box">
                					<input type="text" name="name" placeholder="Your Name" required>
                				</div>
                			</div>              			
                			<div class="col-lg-6">
                				<div class="single-input-box">
                					<input type="text" name="Email" placeholder="Enter E-Mail" required>
                				</div>
                			</div>                			
                			<div class="col-lg-6">
                				<div class="single-input-box">
                					<input type="text" name="Phone" placeholder="Phone Number" required>
                				</div>
                			</div>                			
                			<div class="col-lg-6">
                				<div class="single-input-box">
                					<select name="place" id="place">
						               <option value="saab">Subject</option>
						               <option value="opel">Web Development </option>
						               <option value="opel">App Development </option>
						               <option value="audi">Design </option>
						               <option value="audi">Marketing</option>
					                </select>
                				</div>
                			</div>
                			<div class="col-lg-12">
                				<div class="single-input-box">
                					<textarea name="massage" id="massage" placeholder="Write Massage" required></textarea>
                				</div>
                			</div>
                			<div class="col-lg-12">
                				<div class="massage-sent-button">
                					<button type="submit">Send Massage </button>
                				</div>
                			</div>
                		</div>
                	</form>
                </div>
			</div>
			<div class="col-lg-4 col-md-12">
				<div class="single-contact-info-box">
					<div class="info-content">
						<h4>Don’t Forget to Contact Us</h4>
					</div>
					<div class="contact-info-box">
						<div class="contact-info-icon">
							<i class="bi bi-telephone-fill"></i>
						</div>
						<div class="contact-info-content">
							<p>Call Us</p>
							<h4><a href="tel:+917708504776">+91 77085 04776</a></h4>
						</div>
					</div>					
					<div class="contact-info-box">
						<div class="contact-info-icon">
							<i class="bi bi-envelope-open-fill"></i>
						</div>
						<div class="contact-info-content">
							<p>Send E-Mail</p>
							<h4><a href="mailto:hello@smilemobility.in">hello@smilemobility.in</a></h4>
						</div>
					</div>					
					<div class="contact-info-box">
						<div class="contact-info-icon">
							<i class="fa-regular fa-clock fa-solid fa-location-dot"></i>
						</div>
						<div class="contact-info-content">
							<p>Location</p>
							<h4><a href="https://maps.app.goo.gl/csh7p4gWPEDQiX3H9">Aranthangi,Pudukkottai</a></h4>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Contact Area Style Three-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Google map Area Style Two-->
<!--==================================================-->
<div class="google-map">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
			<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3927.0690827473372!2d78.99789417573149!3d10.175040269996927!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b006ca6aaaaaaab%3A0x40533da9e7c51313!2sNimatooz%20Smile%20Mobility%20PVT%20LTD!5e0!3m2!1sen!2sin!4v1727859469890!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Google map Area Style Two-->
<!--==================================================-->




<!--==================================================-->
<!-- Start Toptech Brand Area Style Two-->
<!--==================================================-->
<div class="brand-area style-two">
	<div class="container">
		<div class="row">
			<div class="brand-list-1 owl-carousel">
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_1.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_2.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_3.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_5.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_6 .png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_9  .png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Brand Area Style Two-->
<!--==================================================-->


<?php include "footer.php"; ?>


<!--==================================================-->
<!-- Start Toptech Scroll Up-->
<!--==================================================-->
<div class="prgoress_indicator active-progress">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
          <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 212.78;"></path>
        </svg>
 </div>
<!--==================================================-->
<!-- End Toptech Scroll Up-->
<!--==================================================-->

	<!-- jquery js -->
	<script src="assets/js/vendor/jquery-3.6.2.min.js"></script>
	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- carousel js -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- wow js -->
	<script src="assets/js/wow.js"></script>
	<!-- ajax-mail js -->
	<script src="assets/js/ajax-mail.js"></script>
	<!-- imagesloaded js -->
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>
	<!-- venobox js -->
	<script src="venobox/venobox.js"></script>
	<!--  animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- venobox min js -->
	<script src="venobox/venobox.min.js"></script>
	<!-- jquery meanmenu js -->
	<script src="assets/js/jquery.meanmenu.js"></script>
	<!-- theme js -->
	<script src="assets/js/theme.js"></script>
	<!-- Cousom carousel js -->
	<script src="assets/js/coustom-carousel.js"></script>
	<script src="assets/js/scroll-up.js"></script>

</body>
</html>