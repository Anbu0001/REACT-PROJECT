
<!DOCTYPE HTML>
<html lang="en-US">

<?php include "head.php"; ?>

<body>
	
<?php include "nav2.php"; ?> 



<!--==================================================-->
<!-- Start Toptech Breadcumb Area -->
<!--==================================================-->
<div class="breadcumb-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="breadcumb-content">
					<h4>Service Details </h4>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li>></li>
						<li>Service Details </li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Breadcumb Area -->
<!--==================================================-->



<!--==================================================-->
<!-- Strat Toptech Service Details Area -->
<!--==================================================-->
<div class="services-details-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-8">
				<div class="row">
					<div class="col-lg-12">
						<div class="services-details-thumb">
							<img src="assets/images/servies/dm.jpg" alt="">
						</div>
						<div class="services-details-content">
							<h4 class="services-details-title">Digital Marketing</h4>
							<h3 class="services-details-title">Search Engine Marketing</h3>

							<p class="services-details-desc">Search engine marketing (SEM) is a digital marketing strategy that is used to increase a website's visibility in search engine results pages (SERPs). </p>

							<p class="services-details-desc">Continually fashion orthogonal leadership skills whereas wireless metrics. Uniquely syndicate exceptional opportunities with interdependent users. Globally enhance fully tested meta-services rather than pandemic solutions. Proactively integrate client-integrate go forward architectures and turnkey meta-services. Interactively harness integrated ROI whereas frictionless  
							products.</p>
						</div>
						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="service-details-icon-box">
									<div class="service-details-icon-thumb">
										<img src="assets/images/service-inner/services-details-icon-1.png" alt="">
									</div>
									<div class="service-details-box-content">
										<h4>Social Media Marketing</h4>
										<p>Social media a type of digital marketing use of the popularity</p>
									</div>
								</div>
							</div>							
							<div class="col-lg-6 col-md-6">
								<div class="service-details-icon-box">
									<div class="service-details-icon-thumb">
										<img src="assets/images/service-inner/services-details-icon-2.png" alt="">
									</div>
									<div class="service-details-box-content">
										<h4>Search Engine Optimization</h4>
										<p>SEO is the single most effective way of driving traffic to your site. </p>
									</div>
								</div>
							</div>
						</div>
						

						<h4 class="services-details-title">What the Benifits?</h4>
						<p class="services-details-desc">We’ll take the time to learn about your business and audience before devising a customized SEM strategy that’s designed to with ROI in mind. </p>

						<div class="row">
							<div class="col-lg-6 col-md-6">
								<div class="single-benifits-box">
									<div class="benifits-thumb">
										<img src="assets/images/service-inner/services-details-benifis-thumb-1.png" alt="">
									</div>
									<div class="benifits-content">
										<h4>Analysis And Planning.</h4>
										<ul>
											<li><i class="bi bi-check2"></i>New Modern Equipments</li>
											<li><i class="bi bi-check2"></i>Expert’s Volunteers</li>
										</ul>
									</div>
								</div>
							</div>							
							<div class="col-lg-6 col-md-6">
								<div class="single-benifits-box">
									<div class="benifits-thumb">
										<img src="assets/images/service-inner/services-details-benifis-thumb-2.png" alt="">
									</div>
									<div class="benifits-content">
										<h4>Design & Development.</h4>
										<ul>
											<li><i class="bi bi-check2"></i>New Modern Equipments</li>
											<li><i class="bi bi-check2"></i>Search Engine Optimization</li>
										</ul>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="row">
					<div class="col-lg-12">
						<div class="widget-sidber">
							<div class="widget-sidber-content">
								<h4>Categories</h4>
							</div>
							<div class="widget-category">
								<ul>
									<li><a href="web-dev.php"><img src="assets/images/service-inner/category-icon.png" alt="">Web Development<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="mobile-dev.php"><img src="assets/images/service-inner/category-icon.png" alt="">App Development<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="web-design.php"><img src="assets/images/service-inner/category-icon.png" alt="">Web Design<i class="bi bi-arrow-right"></i></a></li>								
									<li><a href="digital-marketing.php"><img src="assets/images/service-inner/category-icon.png" alt="">Digital Marketing<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="seo.php"><img src="assets/images/service-inner/category-icon.png" alt="">SEO Marketing<i class="bi bi-arrow-right"></i></a></li>
									<li><a href="sms.php"><img src="assets/images/service-inner/category-icon.png" alt="">Bulk SMS<i class="bi bi-arrow-right"></i></a></li>
								</ul>
							</div>
						</div>						
						<div class="widget-sidber">
							<div class="widget-sidber-content">
								<h4>Downloads</h4>
							</div>
							<div class="widget-sidber-download-button">
								<a href="assets/nsm-brochure.pdf"  download><i class="bi bi-file-earmark-pdf"></i>Service Report<span><i class="bi bi-download"></i></span></a>

								<a class="active" href="assets/nsm-brochure.pdf"  download><i class="bi bi-file-earmark-pdf"></i>Download Lists<span><i class="bi bi-download"></i></span></a>
							</div>
						</div>
						<div class="widget-sidber-contact-box">
							<div class="widget-sidber-contact">
								<img src="assets/images/inner-images/sidber-cont-icon.png" alt="">
							</div>
							<p class="widget-sidber-contact-text">Call Us Anytime</p>
							<h3 class="widget-sidber-contact-number"><a href="tel:+917708504776">+91 77085 04776</a></h3>
							<a class="widget-sidber-contact-gmail text-white" href="mailto:hello@smilemobility.in" target="_blank"><i class="bi bi-envelope-fill"></i> mailto:hello@smilemobility.in</a>
							<div class="widget-sidber-contact-btn">
								<a href="contact.php">Contact Us <i class="bi bi-arrow-right"></i></a>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Service Details Area -->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Brand Area Style Two-->
<!--==================================================-->
<div class="brand-area style-two">
	<div class="container">
		<div class="row">
			<div class="brand-list-1 owl-carousel">
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_1.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_2.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_3.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_5.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_6 .png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_9  .png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Brand Area Style Two-->
<!--==================================================-->


<?php include "footer.php"; ?>




<!--==================================================-->
<!-- Start Toptech Scroll Up-->
<!--==================================================-->
<div class="prgoress_indicator active-progress">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
          <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 212.78;"></path>
        </svg>
 </div>
<!--==================================================-->
<!-- End Toptech Scroll Up-->
<!--==================================================-->

	<!-- jquery js -->
	<script src="assets/js/vendor/jquery-3.6.2.min.js"></script>
	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- carousel js -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- wow js -->
	<script src="assets/js/wow.js"></script>
	<!-- ajax-mail js -->
	<script src="assets/js/ajax-mail.js"></script>
	<!-- imagesloaded js -->
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>
	<!-- venobox js -->
	<script src="venobox/venobox.js"></script>
	<!--  animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- venobox min js -->
	<script src="venobox/venobox.min.js"></script>
	<!-- jquery meanmenu js -->
	<script src="assets/js/jquery.meanmenu.js"></script>
	<!-- theme js -->
	<script src="assets/js/theme.js"></script>
	<!-- Cousom carousel js -->
	<script src="assets/js/coustom-carousel.js"></script>
	<script src="assets/js/scroll-up.js"></script>

</body>
</html>