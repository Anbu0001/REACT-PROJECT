
<!--==================================================-->
<!-- Start Toptech  Top Header Area Style One-->
<!--==================================================-->
<div class="top-header-area">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="header-info ">
					<ul class="d-flex">
						<li class="text-white"><i class="bi bi-geo-alt-fill"></i><a href="https://maps.app.goo.gl/csh7p4gWPEDQiX3H9" target="_blank"> No 103, Agraharam Street, Aranthangi, Pudukkottai<a>&nbsp;</li>
						<li><i class="bi bi-envelope"></i><a href="mailto:hello@smilemobility.in" style="font-size: 16px;" target="_blank">hello@smilemobility.in</a></span></li>
						
					</ul>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="top-header-social-icon">
					<ul>
						<li class="time-line"> <i class="bi bi-telephone"></i><a href="tel:+917708504776" ><span class=" text-white">+91 77085 04776</span></a></li>
						<li><a href="https://www.facebook.com/NimatooZ" rel="noopener" aria-label="facebook" target="_blank" title="facebook"><i class="fa-brands fa-facebook-f"></i></a></li>
						<li><a href="https://twitter.com/SmileMobility" class="d-block" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
						<li><a href="https://www.linkedin.com/in/nimatooz-smile-mobility-pvt-ltd-086113201/" rel="noopener" aria-label="Linked in" target="_blank" title="linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
						<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Top Header Area Style One-->
<!--==================================================-->


<!--==================================================-->
<!-- Start Toptech Header Area Style One-->
<!--==================================================-->
<div class="header-area style-two" id="sticky-header" >
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-3">
				<div class="header-logo">
					<a href="index.php"><img src="assets/images/home-1/logo-.png" alt="logo"></a>
				</div>
			</div>
			<div class="col-lg-9">
				<div class="header-menu">
					<ul>
						<li ><a href="#">Home</a>                          
						</li>
						<li class="menu-item-has-children"><a href="about.php">About</a>                           
						</li>
						<li class="menu-item-has-children"><a href="service.php">Service<i class="fas fa-chevron-down"></i></a>
                           <ul class="sub-menu">
                           	   <li><a href="mobile-dev.php">Mobile App Development</a></li>
                           	   <li><a href="web-dev.php">Web App Development</a></li>
                           	   <li><a href="web-design.php">Web Design</a></li>
                           	   <li><a href="digital-marketing.php">Digital Marketing</a></li>                           	  
                           	   <li><a href="seo.php">SEO Marketing</a></li>                           	  
                           	   <li><a href="sms.php">Bulk SMS</a></li>                           	  
                           </ul>
						</li> 
						</li>
						<li><a href="contact.php">Contact</a></li>
					</ul>
					
					<div class="header-button">
						<a href="contact.php">Get A Quote</a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Header Area Style One-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Main Menu Area -->
<!--==================================================-->
<div class="mobile-menu-area sticky d-sm-block d-md-block d-lg-none ">
	<div class="mobile-menu">
		<nav class="header-menu">
			<ul class="nav_scroll">
				<li class="menu-item-has-children"><a href="#">Home</a>
                  
				</li>
				<li class="menu-item-has-children"><a href="about.php">About</a>
                   
				</li>
				<li class="menu-item-has-children"><a href="service.php">Service</a>
				<ul class="sub-menu">
                           	   <li><a href="mobile-dev.php">Mobile App Development</a></li>
                           	   <li><a href="web-dev.php">Web App Development</a></li>
                           	   <li><a href="web-design.php">Web Design</a></li>
                           	   <li><a href="digital-marketing.php">Digital Marketing</a></li> 
								  <li><a href="seo.php">SEO Marketing</a></li>                           	  
                           	   <li><a href="sms.php">Bulk SMS</a></li>                          	  
                           </ul>
				</li>

				
				<li><a href="contact.php">Contact</a></li>
			
			</ul>
		</nav>
	</div>
</div>
<!--==================================================-->
<!-- End Main Menu Area -->
<!--==================================================-->