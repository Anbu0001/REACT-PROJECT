<!DOCTYPE HTML>
<html lang="en-US">

<?php include "head.php"; ?>

<body>

<?php include "nav.php"; ?>



<!--==================================================-->
<!-- Start Toptech Hero Area Style One-->
<!--==================================================-->
<div class="hero-area style-two d-flex align-items-center">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-8">
				<div class="hero-content">
					<h4 class="text-primary"> NimatooZ smile Mobility Pvt Ltd. </h4>
					<h1> Best Web and Mobile </h1>
					<h1> Application Development</h1>
					<p>Nimatooz Smile Mobility Pvt Ltd is an established global company focusing on business intelligence, mobile application and web design. Our client site includes companies of all sizes from start-ups to large companies.
				    </p>
				</div>
				<div class="hero-button">
					<a href="contact.php">Lets Talk<i class="bi bi-arrow-right"></i></a>
					<a class="button-two" href="about.php">Read More<i class="bi bi-arrow-right"></i></a>
				</div>
			</div>
			<div class="col-lg-4">
				<div class="hero-right">
					<div class="hero-thumb">
						<img src="assets/images/home-2/hero-thumb.png" alt="">
					</div>
					<div class="hero-shape">
						<img src="assets/images/home-2/hero-shape.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Hero Area Style One-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Feature Area Style Two-->
<!--==================================================-->
<div class="feature-area style-two">
	<div class="container">
        <div class="row add-marging">
        	<div class="col-lg-4 col-md-6">
        		<div class="single-feature-box">
        			<div class="feature-icon">
        				<img src="assets/images/home-2/feature-icon1.png" alt="">
        			</div>
        			<div class="feature-content">
        				<h4>35+ Year Experience Company NMS</h4>
        				<p>Celebrating 35 years! Let's take the moment to reflect milestone and a positive Experience Company NMS.</p>
        				
        			</div>
        		</div>
        	</div>        	
        	<div class="col-lg-4 col-md-6">
        		<div class="single-feature-box">
        			<div class="feature-icon">
        				<img src="assets/images/home-2/feature-icon2.png" alt="">
        			</div>
        			<div class="feature-content">
        				<h4>Solving Problems, Building Brands</h4>
        				<p>We believe brand interaction is key in communication. Real innovations and a positive.</p>
        				
        			</div>
        		</div>
        	</div>        	
        	<div class="col-lg-4 col-md-6">
        		<div class="single-feature-box">
        			<div class="feature-icon">
        				<img src="assets/images/home-2/feature-icon3.png" alt="">
        			</div>
        			<div class="feature-content">
        				<h4>Enjoy Full-Service Mobility Expertise</h4>
        				<p>We are here to style what you would like . Our team of execs will create attractive designs. </p>
        				
        			</div>
        		</div>
        	</div>
        </div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Feature Area Style Two-->
<!--==================================================-->


<!--==================================================-->
<!-- Start Toptech About Area Style two-->
<!--==================================================-->
<div class="about-area style-two">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="about-left">
					<div class="about-thumb">
						<img src="assets/images/home-2/about-thumb.png" alt="">
					</div>
					<div class="about-shape">
						<img src="assets/images/home-2/about-shape.png" alt="">
					</div>
					<div class="about-conter-box">
						<div class="about-counter-title">
							<h4>35</h4>
							<span>+</span>
							<p>Years Of <br> Experiences </p>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="about-right">
					<div class="section-title left style-two">
						<h4>About Our Company</h4>
						<h1>Web Design and Development company in chennai</h1>
						<h1></h1>
						<p>Nimatooz Smile Mobility Pvt Ltd is one of the best web design and development company in India. Web Design and Application Development for startups, medium and large enterprises businesses. We create technologies, that will help your brand identity be taken to the next level.</p>
					</div>
					<div class="row">
						<div class="col-lg-6 col-md-6">
							<div class="single-about-icon-box">
								<div class="about-icon">
									<img src="assets/images/home-2/about-icon1.png" alt="">
								</div>
								<div class="about-icon-box-content">
									<h4>100% Money Back Gaurentee</h4>
								</div>
							</div>
						</div>						
						<div class="col-lg-6 col-md-6">
							<div class="single-about-icon-box">
								<div class="about-icon">
									<img src="assets/images/home-2/about-icon2.png" alt="">
								</div>
								<div class="about-icon-box-content">
									<h4>Expert & Dedicated Team Members</h4>
								</div>
							</div>
						</div>						
						<div class="col-lg-6 col-md-6">
							<div class="single-about-icon-box">
								<div class="about-icon">
									<img src="assets/images/home-2/about-icon3.png" alt="">
								</div>
								<div class="about-icon-box-content">
									<h4>24/7 Free Tehcnical Supports</h4>
								</div>
							</div>
						</div>						
						<div class="col-lg-6 col-md-6">
							<div class="single-about-icon-box">
								<div class="about-icon">
									<img src="assets/images/home-2/about-icon4.png" alt="">
								</div>
								<div class="about-icon-box-content">
									<h4>100% Customers Satisfaction</h4>
								</div>
							</div>
						</div>
					</div>
					<div class="toptech-button style-one">
						<a href="about.php">About More<i class="bi bi-arrow-right-circle-fill"></i></a>
					</div>
					<div class="about-shape-two">
						<img src="assets/images/home-2/about-shape2.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech About Area Style One-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Service Area Style Two-->
<!--==================================================-->
<div class="service-area style-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="section-title center style-two">
					<h4>Services </h4>
					<h1>Let’s Check Our Services</h1>
					
			    </div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="single-services-box">
					<div class="service-icon-thumb">
						<img src="assets/images/home-2/service-1.png" alt="">
					</div>
					<div class="service-number">
						<h1>01</h1>
					</div>
					<div class="service-content">
						<h4>Website Design</h4>
						<p>Website design encompasses the visual and functional aspects of creating digital platforms for...</p>
						<a href="web-dev.php">Read More<i class="bi bi-arrow-right"></i></a>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-services-box">
					<div class="service-icon-thumb">
						<img src="assets/images/home-2/service-2.png" alt="">
					</div>
					<div class="service-number">
						<h1>02</h1>
					</div>
					<div class="service-content">
						<h4>Web App Development</h4>
						<p>Web app development involves creating interactive applications accessible via web browsers. It...</p>
						<a href="web-dev.php">Read More<i class="bi bi-arrow-right"></i></a>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-services-box">
					<div class="service-icon-thumb">
						<img src="assets/images/home-2/service-3.png" alt="">
					</div>
					<div class="service-number">
						<h1>03</h1>
					</div>
					<div class="service-content">
						<h4>Mobile Application Development</h4>
						<p>Mobile application development involves designing and building software specifically for use on...

</p>
						<a href="mobile-dev.php">Read More<i class="bi bi-arrow-right"></i></a>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-services-box">
					<div class="service-icon-thumb">
						<img src="assets/images/home-2/service-4.png" alt="">
					</div>
					<div class="service-number">
						<h1>04</h1>
					</div>
					<div class="service-content">
						<h4>Digital Marketing</h4>
						<p>Monotonectally synergize grants to business visualize strategic infomediaries in...</p>
						<a href="digital-marketing.php">Read More<i class="bi bi-arrow-right"></i></a>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-services-box">
					<div class="service-icon-thumb">
						<img src="assets/images/home-2/service-6.png" alt="">
					</div>
					<div class="service-number">
						<h1>05</h1>
					</div>
					<div class="service-content">
						<h4>SEO Marketing</h4>
						<p>Monotonectally synergize grants to business visualize strategic infomediaries a...</p>
						<a href="seo.php">Read More<i class="bi bi-arrow-right"></i></a>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-services-box">
					<div class="service-icon-thumb">
						<img src="assets/images/home-2/service-5.png" alt="">
					</div>
					<div class="service-number">
						<h1>06</h1>
					</div>
					<div class="service-content">
						<h4>Bulk SMS</h4>
						<p>Graphics design services involve creating visual content for various purposes such as branding,...</p>
						<a href="sms.php">Read More<i class="bi bi-arrow-right"></i></a>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Service Area Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Team Area  Style Two-->
<!--==================================================-->
<div class="team-area style-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-7">
			    <div class="section-title left style-two">
        			<h4>Dedicated Team</h4>
        			<h1>Meet Our Dedicated Member</h1>
        			<h1>For Any Enquery</h1>
        		</div>
			</div>
			<div class="col-lg-5">
			    <div class="toptech-button style-one">
                	<a href="contact.php>All Member<i class="bi bi-arrow-right-circle-fill"></i></a>
                </div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-3 col-md-6">
				<div class="single-team-box">
					<div class="team-thumb">
						<img src="assets/images/team/team.jpg" alt="">
					</div>
					<div class="team-content">
						<h4>John D. Alexon</h4>
						<p>Manager</p>
						<div class="team-shape">
							<img src="assets/images/team/team-shape.png" alt="">
						</div>
					</div>
					<div class="team-socila-icon-box">
						<div class="team-share">
							<div class="team-share-icon">
								<span><i class="bi bi-share"></i></span>
							</div>
						</div>
						<div class="team-social-icon">
							<ul>
								<li><a href="https://www.facebook.com/NimatooZ" rel="noopener" aria-label="facebook" target="_blank" title="facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/SmileMobility" class="d-block" target="_blank"><i class="fab fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/in/nimatooz-smile-mobility-pvt-ltd-086113201/" rel="noopener" aria-label="Linked in" target="_blank" title="linkedin"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6">
				<div class="single-team-box">
					<div class="team-thumb">
						<img src="assets/images/team/team.jpg" alt="">
					</div>
					<div class="team-content">
						<h4>Alexina Gomez</h4>
						<p>HR Manager</p>
						<div class="team-shape">
							<img src="assets/images/team/team-shape.png" alt="">
						</div>
					</div>
					<div class="team-socila-icon-box">
						<div class="team-share">
							<div class="team-share-icon">
								<span><i class="bi bi-share"></i></span>
							</div>
						</div>
						<div class="team-social-icon">
							<ul>
								<li><a href="https://www.facebook.com/NimatooZ" rel="noopener" aria-label="facebook" target="_blank" title="facebook" rel="noopener" aria-label="facebook" target="_blank" title="facebook"i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/SmileMobility" class="d-block" target="_blank"><i class="fab fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/in/nimatooz-smile-mobility-pvt-ltd-086113201/" rel="noopener" aria-label="Linked in" target="_blank" title="linkedin"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6">
				<div class="single-team-box">
					<div class="team-thumb">
						<img src="assets/images/team/team.jpg" alt="">
					</div>
					<div class="team-content">
						<h4>Antoine Brown</h4>
						<p>Developer</p>
						<div class="team-shape">
							<img src="assets/images/team/team-shape.png" alt="">
						</div>
					</div>
					<div class="team-socila-icon-box">
						<div class="team-share">
							<div class="team-share-icon">
								<span><i class="bi bi-share"></i></span>
							</div>
						</div>
						<div class="team-social-icon">
							<ul>
								<li><a href="https://www.facebook.com/NimatooZ" rel="noopener" aria-label="facebook" target="_blank" title="facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/SmileMobility" class="d-block" target="_blank"><i class="fab fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/in/nimatooz-smile-mobility-pvt-ltd-086113201/" rel="noopener" aria-label="Linked in" target="_blank" title="linkedin"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6">
				<div class="single-team-box">
					<div class="team-thumb">
						<img src="assets/images/team/team.jpg" alt="">
					</div>
					<div class="team-content">
						<h4>Carolina Scott</h4>
						<p>UI Designer</p>
						<div class="team-shape">
							<img src="assets/images/team/team-shape.png" alt="">
						</div>
					</div>
					<div class="team-socila-icon-box">
						<div class="team-share">
							<div class="team-share-icon">
								<span><i class="bi bi-share"></i></span>
							</div>
						</div>
						<div class="team-social-icon">
							<ul>
								<li><a href="https://www.facebook.com/NimatooZ" rel="noopener" aria-label="facebook" target="_blank" title="facebook"><i class="fab fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/SmileMobility" class="d-block" target="_blank"><i class="fab fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/in/nimatooz-smile-mobility-pvt-ltd-086113201/" rel="noopener" aria-label="Linked in" target="_blank" title="linkedin"><i class="fab fa-instagram"></i></a></li>
								<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>			
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Team Area Style Two-->
<!--==================================================-->




<!--==================================================-->
<!-- Start Toptech Counter Area Home two-->
<!--==================================================-->
<div class="counter-area style-two">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-3 col-md-6">
				<div class="counter-box">
					<div class="counter-content">
						<h4 class="counterup">10</h4>
						<span>K+</span>
						<p>happy customers</p>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6">
				<div class="counter-box">
					<div class="counter-content">
						<h4 class="counterup">20</h4>
						<span>K+</span>
						<p>Works Completed</p>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6">
				<div class="counter-box">
					<div class="counter-content">
						<h4>99</h4>
						<span>+</span>
						<p>Expert Members</p>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6">
				<div class="counter-box">
					<div class="counter-content">
						<h4>100</h4>
						<span>%</span>
						<p>Satisfaction Rates</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- Start Toptech Counter Area Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Portfolio Area  Style Two-->
<!--==================================================-->
<div class="portfolio-area style-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="section-title center style-two">
					<h4>IT Support For Business</h4>
					<h1>Ensuring Your Success Trusted</h1>
					<h1>IT Services Source</h1>
				</div>
			</div>
		</div>
	</div>

	<div class="container-fluid">
		<div class="row">
			<div class="col-md-12">
				<div class="portfolio_nav">
					<div class="portfolio_menu">
						<ul class="menu-filtering">
							<li class="current_menu_item" data-filter="*"> All items </li>
							<li data-filter=".technology">Technology </li>
							<li data-filter=".designing">Designing </li>
							<li data-filter=".bussiness"> Bussiness </li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<div class="row image_load">
			<div class="col-lg-4 col-md-6 grid-item technology">
				<div class="single-portfolio-box">
					<div class="portfolio-thumb">
						<img src="assets/images/home-2/1.jpg" alt="">
					</div>
					<div class="portfolio-content">
						<div class="portfolio-number">
							<h1>01</h1>
						</div>
						<div class="portfolio-title">
							<a href="contact.php">POS App <i class="bi bi-plus"></i></a>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6 grid-item designing">
				<div class="single-portfolio-box">
					<div class="portfolio-thumb">
						<img src="assets/images/home-2/3.jpg" alt="">
					</div>
					<div class="portfolio-content">
						<div class="portfolio-number">
							<h1>02</h1>
						</div>
						<div class="portfolio-title">
							<a href="contact.php"> Get Free Quote<i class="bi bi-plus"></i></a>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6 grid-item bussiness">
				<div class="single-portfolio-box">
					<div class="portfolio-thumb">
						<img src="assets/images/home-2/2.jpg" alt="">
					</div>
					<div class="portfolio-content">
						<div class="portfolio-number">
							<h1>03</h1>
						</div>
						<div class="portfolio-title">
							<a href="contact.php">Food Delivery<i class="bi bi-plus"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Portfolio Area  Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Working Process Area  Style Two-->
<!--==================================================-->
<div class="working-proces-area style-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="section-title center style-two">
					<h4>Working Process</h4>
					<h1>We Follow the Easy Working Steps</h1>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="working-process-box before-transprent after-transprent">
					<div class="process-thumb">
						<img src="assets/images/home-2/process-1.png" alt="">
						<div class="process-number">
							<span>01</span>
						</div>
					</div>
					<div class="process-content">
						<h4>Start A Project</h4>
						<p>Ready to bring your ideas to life? Starting a project with us is simple and efficient. Whether you need web development, app creation, or custom software solutions, our expert team is here to guide you every step of the way. From initial consultation to final delivery, we ensure a smooth process tailored.</p>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="working-process-box after-transprent">
					<div class="process-thumb">
						<img src="assets/images/home-2/process-2.png" alt="">
						<div class="process-number two">
							<span>02</span>
						</div>
					</div>
					<div class="process-content">
						<h4>Project Analysis</h4>
						<p>A thorough project analysis is essential to ensure your project's success. Our team conducts a detailed evaluation of your requirements, goals, and potential challenges to create a roadmap tailored to your vision. We begin by identifying the project scope, timelines, and resource needs, ensuring clarity.</p>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="working-process-box before-transprent">
					<div class="process-thumb">
						<img src="assets/images/home-2/process-3.png" alt="">
						<div class="process-number">
							<span>03</span>
						</div>
					</div>
					<div class="process-content">
						<h4>Deliver to Success</h4>
						<p>At every stage of your project, our focus is on delivering success. From planning to execution, we ensure that your goals are met with precision and excellence. Our team follows a results-driven approach, aligning project milestones with your vision and business objectives.
						 to planning</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Working Process Area  Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Testimonial Area Style One-->
<!--==================================================-->
<div class="testimonial-area style-one">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="section-title center style-two">
        			<h4>Testimonial</h4>
        			<h1>Customer’s Awesome Feedback</h1>
        			<h1>About Our Services</h1>
        		</div>
			</div>
		</div>
		<div class="row">
			<div class="testi-list-1 owl-carousel">
			   <div class="col-lg-12 text-center">
					<div class="single-testimonial-box">
						<div class="testi-desc">
							<p>"On top of it all, your customer service and Nimatooz Smile Mobility were impeccable, making the experience of working with your team an absolute pleasure. You were able to complete each task efficiently and on time."</p>
						</div>
						<div class="testi-rating">
							<ul>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
							</ul>
						</div>
						<div class="testi-author">
							<h4>Mukesh</h4>
							
						</div>
					</div>
			   </div>			   
			   <div class="col-lg-12 text-center">
					<div class="single-testimonial-box">
						<div class="testi-desc">
							<p>"We love Nimatooz Smile Mobility and our business would definitely not be as successful as it is without their help and guidance. If you want to take your business to the next level, look no further than Nimatooz Smile Mobility."</p>
						</div>
						<div class="testi-rating">
							<ul>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
							</ul>
						</div>
						<div class="testi-author">
							<h4>Peer Mohammad</h4>
						
						</div>
					</div>
			   </div>			   
			   <div class="col-lg-12 text-center">
					<div class="single-testimonial-box">
						<div class="testi-desc">
							<p>"I’ve had some questionable experiences with other web agencies in the past, but Nimatooz Smile Mobility has hands down been the best web company we’ve worked with, providing us with peace of mind and incredible service."</p>
						</div>
						<div class="testi-rating">
							<ul>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
							</ul>
						</div>
						<div class="testi-author">
							<h4>Senthil kumar </h4>
							
						</div>
					</div>
			   </div>			   
			   <div class="col-lg-12 text-center">
					<div class="single-testimonial-box">
						<div class="testi-desc">
							<p>Completely extend leveraged customer service rather than performance based imperatives.
	                         magnetic relationships rather than leveraged e-markets. Rapidiously transform timely niches
	                         technology. Enthusiastically e-enable global e-markets for cooperative e-business. 
	                         Authoritatively deliver highly efficient expertise</p>
						</div>
						<div class="testi-rating">
							<ul>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
								<li><i class="bi bi-star-fill"></i></li>
							</ul>
						</div>
						<div class="testi-author">
							<h4>Abhishek Sharma</h4>
							
						</div>
					</div>
			   </div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Testimonial Area Style One-->
<!--==================================================-->


<!--==================================================-->
<!-- Start Toptech Video Area Style Two-->
<!--==================================================-->
<div class="video-area style-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="section-title center style-two">
					<h4>Watch Now</h4>
					<h1>Our Best Working Process System</h1>
					<h1>with Team Expert Leaders</h1>
				</div>
			</div>
			<div class="col-lg-12">
				<div class="video-button">
					<a class="video-vemo-icon venobox vbox-item" data-vbtype="youtube" data-autoplay="true" href="https://youtu.be/6Wp5F4WI74c?si=r2e7CPATbNjy8vk0" target="_blank"><i class="bi bi-play-fill"></i></a>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Video Area Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech contact info Area Style Two-->
<!--==================================================-->
<div class="contact-info-area style-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="contact-info-box">
					<div class="contact-info-icon">
						<i class="fa-solid fa-phone"></i>
					</div>
					<div class="contact-info-content">
						<h4>Call us Any time</h4>
						<p><a href="tel:+917708504776" class="text-black">+91 77085 04776</a></p>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="contact-info-box">
					<div class="contact-info-icon">
						<i class="fa-regular fa-envelope"></i>
					</div>
					<div class="contact-info-content">
						<h4>Send E-Mail</h4>
						<p><a href="mailto:hello@smilemobility.in" class="text-black" target="_blank">hello@smilemobility.in</a></p>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="contact-info-box">
					<div class="contact-info-icon">
						<i class="fa-regular fa-clock fa-solid fa-location-dot"></i>
					</div>
					<div class="contact-info-content">
						<h4>Location</h4>
						<p><a href="https://maps.app.goo.gl/csh7p4gWPEDQiX3H9" class="text-black" target="_blank">Aranthangi, Pudukkottai</a></p>						
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech contact info Area Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Pricing Area Style Two-->
<!--==================================================-->
<div class="pricing-area style-two">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
	            <div class="section-title left style-two">
	    			<h4>Pricing Plan </h4>
	    			<h1>Our Best Affordable Pricing Plan</h1>
	    			<h1>Choose Your Plans</h1>
	        	</div>
	        	<div class="faqs-container">
					<div class="faq-singular">
					    <h2 class="faq-question">How to increase products sales 2024?</h2>
					    <div class="faq-answer">
					      <div class="desc">
                            
To increase product sales in 2024, focus on personalization through AI, leverage social media and influencer marketing, and ensure a mobile-friendly shopping experience. 
					      </div>
					    </div>
				    </div>					
				    <div class="faq-singular">
					    <h2 class="faq-question">What kinds of web traffics?</h2>
					    <div class="faq-answer">
					      <div class="desc">
						  Web traffic comes from various sources, each offering unique insights into how visitors reach your site. Organic traffic is driven by search engine results through SEO efforts, while direct traffic comes from users who type your URL directly.
					      </div>
					    </div>
				    </div>					    
				    <div class="faq-singular">
					    <h2 class="faq-question">How to generate organic audience?</h2>
					    <div class="faq-answer">
					      <div class="desc">
						  To generate an organic audience, focus on optimizing your website for SEO by using relevant keywords and creating high-quality content that addresses your audience's needs. Share valuable blog posts and resources on social media to increase visibility.
					      </div>
					    </div>
				    </div>					    
				    <div class="faq-singular">
					    <h2 class="faq-question">Do you have any custom services?</h2>
					    <div class="faq-answer">
					      <div class="desc">
						  Yes, we offer a range of custom services tailored to meet your unique needs. Whether you require personalized web development, custom app solutions, or specialized marketing strategies, our team is equipped to deliver high-quality results.   
					      </div>
					    </div>
				    </div>										 						
                </div>
        	</div>
        	<div class="col-lg-6">
        		<div class="pricing-right">
        		    <div class="single-pricing-box">
        			    <div class="pricing-body">
        			       <a class="pricing-tag" href="#">Business</a>
        			       <span class="pricing-text">For 1 Years </span>
        			       <h4 class="pricing">$39. <span>98</span></h4>
        			    </div>
        			    <div class="pricing-content">
        			    	<div class="pricing-icon">
        			    		<i class="bi bi-check-square-fill"></i>
        			    	</div>
        			    	<div class="pricing-title">
        			    		<h4>19 Days For Free</h4>
        			    		<p>Experience our premium services with a complimentary 19-day trial! Explore all the features and benefits we offer without any commitment.</p>
        			    		<a href="#">Purchaces</a>
        			    	</div>
        			    </div>
        		    </div>        		    
        		    <div class="single-pricing-box two">
        			    <div class="pricing-body">
        			       <a class="pricing-tag" href="#">Popular</a>
        			       <span class="pricing-text">For 1 Month </span>
        			       <h4 class="pricing">$49. <span>90</span></h4>
        			    </div>
        			    <div class="pricing-content">
        			    	<div class="pricing-icon">
        			    		<i class="bi bi-check-square-fill"></i>
        			    	</div>
        			    	<div class="pricing-title">
        			    		<h4>90 Days For Free</h4>
        			    		<p>Unlock a world of possibilities with our exclusive 90-day free trial! Take advantage of our premium services, including web development, digital marketing, and custom solutions, all at no cost to you.</p>
        			    		<a href="#">Purchaces</a>
        			    	</div>
        			    </div>
        		    </div>
        		</div>
        	</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Pricng info Area Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Blog Area Style One-->
<!--==================================================-->
<div class="blog-area style-one home-two">
	<div class="container">
		<div class="row">
			<div class="col-lg-12 text-center">
				<div class="section-title center style-two">
					<h4>Latest Blog</h4>
					<h1>Latest Inshights From Our Blog</h1>
			    </div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="single-blog-box">
					<div class="blog-thumb">
						<img src="assets/images/home-1/11.jpg" alt="">
					</div>
					<div class="blog-content">
						<div class="blog-meta">
							<span><i class="bi bi-calendar-check-fill"></i> Now</span>
						</div>
						<a href="digital-marketing.php">Why Digital Marketing Situation</a>
						<p>A digital marketing situation typically refers  environment business's digital marketing efforts. It helps analyze the strategies to the digital landscape.</p>
					</div>
					<div class="blog-buttom">
						<div class="blog-author">
							<span><i class="bi bi-person-circle"></i>By Ajith </span>
						</div>
						<div class="blog-button">
							<a href="digital-marketing.php">More Details<i class="bi bi-arrow-right-short"></i></a>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-blog-box">
					<div class="blog-thumb">
						<img src="assets/images/home-1/33.jpg" alt="">
					</div>
					<div class="blog-content">
						<div class="blog-meta">
							<span><i class="bi bi-calendar-check-fill"></i> Now</span>
						</div>
						<a href="seo.php">Computer Software developer CRM </a>
						<p>A Computer Software Developer CRM (Customer Relationship Management) specializes designing, and maintaining CRM manage their interactions with customers. </p>
					</div>
					<div class="blog-buttom">
						<div class="blog-author">
							<span><i class="bi bi-person-circle"></i>By Vijay </span>
						</div>
						<div class="blog-button">
							<a href="seo.php">More Details<i class="bi bi-arrow-right-short"></i></a>
						</div>
					</div>
				</div>
			</div>			
			<div class="col-lg-4 col-md-6">
				<div class="single-blog-box">
					<div class="blog-thumb">
						<img src="assets/images/home-1/44.jpg" alt="">
					</div>
					<div class="blog-content">
						<div class="blog-meta">
							<span><i class="bi bi-calendar-check-fill"></i> Now</span>
						</div>
						<a href="mobile-dev.php">iOS Mobile Application Development</a>\
						<p>iOS Mobile Application Development refers to the process of creating on the software applications you haave a graet that run on Apple’s iOS operating system.</p>
					</div>
					<div class="blog-buttom">
						<div class="blog-author">
							<span><i class="bi bi-person-circle"></i>By Karthi </span>
						</div>
						<div class="blog-button">
							<a href="mobile-dev.php">More Details<i class="bi bi-arrow-right-short"></i></a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Blog Area Style One-->
<!--==================================================-->


<!--==================================================-->
<!-- Start Toptech Brand Area Style Two-->
<!--==================================================-->
<div class="brand-area style-two">
	<div class="container">
		<div class="row">
			<div class="brand-list-1 owl-carousel">
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_1.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_2.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_3.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_5.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_6 .png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_9  .png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Brand Area Style Two-->
<!--==================================================-->


<?php include "footer.php"; ?>



<!--==================================================-->
<!-- Start Toptech Search-->
<!--==================================================-->
<div class="search-popup">
	<button class="close-search style-two"><span class="flaticon-multiply"><i class="far fa-times-circle"></i></span></button>
	<button class="close-search"><i class="bi bi-arrow-up"></i></button>
	<form method="post" action="#">
		<div class="form-group">
			<input type="search" name="search-field" value="" placeholder="Search Here" required="">
			<button type="submit"><i class="fa fa-search"></i></button>
		</div>
	</form>
</div>
<!--==================================================-->
<!-- End Toptech Search-->
<!--==================================================-->

<!--==================================================-->
<!-- Start Toptech Scroll Up-->
<!--==================================================-->
<div class="prgoress_indicator active-progress">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
          <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 212.78;"></path>
        </svg>
 </div>
<!--==================================================-->
<!-- End Toptech Scroll Up-->
<!--==================================================-->

	<!-- jquery js -->
	<script src="assets/js/vendor/jquery-3.6.2.min.js"></script>
	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- carousel js -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- wow js -->
	<script src="assets/js/wow.js"></script>
	<!-- ajax-mail js -->
	<script src="assets/js/ajax-mail.js"></script>
	<!-- imagesloaded js -->
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>
	<!-- venobox js -->
	<script src="venobox/venobox.js"></script>
	<!--  animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<script src="assets/js/isotope.pkgd.min.js"></script>
	<!-- venobox min js -->
	<script src="venobox/venobox.min.js"></script>
	<!-- jquery meanmenu js -->
	<script src="assets/js/jquery.meanmenu.js"></script>
	<!-- theme js -->
	<script src="assets/js/theme.js"></script>
	<!-- Cousom carousel js -->
	<script src="assets/js/coustom-carousel.js"></script>
	<script src="assets/js/scroll-up.js"></script>

</body>
</html>