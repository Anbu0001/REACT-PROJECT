
<!DOCTYPE HTML>
<html lang="en-US">

<?php include "head.php"; ?>

<body>

<?php include "nav2.php"; ?> 



<!--==================================================-->
<!-- Start Toptech Breadcumb Area -->
<!--==================================================-->
<div class="breadcumb-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="breadcumb-content">
					<h4>About Us</h4>
					<ul>
						<li><a href="index.php">Home</a></li>
						<li>></li>
						<li>About</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Breadcumb Area -->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech About Area Inner Style Two-->
<!--==================================================-->
<div class="about-area inner-style-two">
	<div class="container">
		<div class="row align-items-center">
            <div class="col-lg-6">
            	<div class="about-left">
	            	<div class="about-thumb">
	            		<img src="assets/images/about-inner/about-thumb-2.png" alt="">
	            	</div>
	            	<div class="about-video-box">
	            		<a class="video-vemo-icon venobox vbox-item" data-vbtype="youtube" data-autoplay="true" href="https://youtu.be/6Wp5F4WI74c?si=0g7FgGhFYTuVZMXM" target="_blank"><i class="bi bi-play-fill"></i></a>
	            	</div>
            	</div>
            </div>
            <div class="col-lg-6">
            	<div class="abour-right">
            		<div class="section-title left inner-style">
            			<h4>About Our Company</h4>
            			<h1>We Have A Smart Solution For Each</h1>
            			
            			<p class="section-desc">At NimatooZ Smile Mobility Private Limited, we are passionate about web design. With years of experience in the industry, our team has the skills and expertise to create beautiful, functional websites that exceed your expectations. Whether you 're a small business looking to establish an online presence or a large company in need of a website overhaul, we have the tools and knowledge to help you succeed at the best web design company.</p>
            		</div>
            		<div class="about-single-box">
            			<div class="about-icon">
            				<img src="assets/images/about-inner/about-icon.png" alt="">
            			</div>
            			<div class="about-box-content">
            				<h4>Who We Are</h4>
            				<p>NimatooZ from ideation to execution, enabling Global 99+ clients. The collaborative approach  value chain.</p>
            			</div>
            		</div>            		
            		<div class="about-single-box">
            			<div class="about-icon">
            				<img src="assets/images/about-inner/about-icon.png" alt="">
            			</div>
            			<div class="about-box-content">
            				<h4>Our Mission</h4>
            				<p>Delivering business solutions for the web and mobile world Bring enabling Global your ideas to life.</p>
            			</div>
            		</div>
            	</div>
            	<div class="about-single-button">
            		<a href="service.php">Service</a>
            	</div>            	
            	<div class="about-single-button">
            		<a href="contact.php">Contact</a>
            	</div>
            </div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech About Area Inner Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Contact info Area Style Three-->
<!--==================================================-->
<div class="contact-area-info style-three">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="contact-icon">
					<img src="assets/images/home-3/contact-icon.png" alt="">
				</div>
				<div class="contact-content">
					<h6>Call Us Anytime</h6>
					<h1><a href="tel:+917708504776">+91 77085 04776</a></h1>
					<p>Professionally optimize interdependent intellectual interoperable 
                     best practices. Progressively fabricate</p>
				</div>
				<div class="toptech-button inner-style">
                    <a href="contact.php">Let’s Talk<i class="bi bi-arrow-right-short"></i></a>
                </div>
			</div>
			<div class="col-lg-6">
				<div class="contact-right">
					<div class="contact-thumb">
						<img src="assets/images/home-3/contact-thumb.png" alt="">
					</div>
					<div class="contact-shape">
						<img src="assets/images/home-3/contact-shape.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Contact info Area Style Three-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Counter Area Home Three-->
<!--==================================================-->
<div class="counter-area style-three">
	<div class="container">
		<div class="row add-bg">
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter-box">
					<div class="counter-content">
						<h4>960</h4>
						<span>+</span>
						<p>Active Coustomer </p>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter-box">
					<div class="counter-content">
						<h4>90</h4>
						<span>+</span>
						<p>Expert Members </p>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter-box">
					<div class="counter-content">
						<h4>1K</h4>
						<span>+</span>
						<p>Satisfied Customers </p>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6 col-sm-6">
				<div class="single-counter-box last-child">
					<div class="counter-content">
						<h4>100</h4>
						<span>%</span>
						<p>Satisfaction Rate </p>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Counter Area Style Three-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Choose Us Area Style Three-->
<!--==================================================-->
<div class="choose-us-area style-three">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
			    <div class="section-title left inner-style">
        			<h4>OUR HISTORY</h4>
        			<h1>History Begins In 2012</h1>
        			
        			<p class="section-desc">
					<h4>Founder</h4> The foundation of Nimatooz Smile Mobility Pvt Ltd. was started by one person as a freelancer under the name Nimatooz Smile solution, Nimatooz Smile Mobility Pvt Ltd. founded based on only trust. our main intention is to create a complete digital enabling of the business or create a digital transformation of the business to help them scale to the next level.</p>
            	</div>
				<div class="wrapper">
			        <div class="skill">
			            <p>IT Solutions</p>
			            <div class="skill-bar skill1 wow slideInLeft animated">
			                <span class="skill-count1">95%</span>
			            </div>
			        </div>
			        <div class="skill">
			            <p>Development</p>
			            <div class="skill-bar skill2 wow slideInLeft animated">
			                 <span class="skill-count2">85%</span>
			            </div>
			        </div>
			        <div class="toptech-button inner-style">
                    	<a href="contact.php">More Contact<i class="bi bi-arrow-right-short"></i></a>
                    </div>
				</div>
			</div>
			<div class="col-lg-3 col-md-6 col-sm-6">
               <div class="single-pricing-box">
               	   <div class="pricing-icon">
               	   	  <img src="assets/images/home-3/pricing-icon.png" alt="">
               	   </div>
               	   <div class="pricing-content">
               	   	   <h4>Busines Plan</h4>
               	   	   <p>The markets and front market</p>
               	   	   <h1>$30 <span>/ Month</span> </h1>
               	   </div>
               	   <div class="pricing-list">
               	   	    <ul>
               	   	    	<li>10+ user Account</li>
               	   	    	<li>Moneyback Gaurentee</li>
               	   	    	<li>Unlimited Database</li>
               	   	    	<li>24/7 Supports</li>
               	   	    </ul>
               	   </div>
               	   <div class="pricing-button">
               	   	   <a href="#">Purchaces</a>
               	   </div>
               </div>
			</div>			
			<div class="col-lg-3 col-md-6 col-sm-6">
               <div class="single-pricing-box two">
               	   <div class="pricing-icon">
               	   	  <img src="assets/images/home-3/pricing-icon.png" alt="">
               	   </div>
               	   <div class="pricing-content">
               	   	   <h4>Popular Plan</h4>
               	   	   <p>The markets and front market</p>
               	   	   <h1>$10 <span>/ Month</span> </h1>
               	   </div>
               	   <div class="pricing-list">
               	   	    <ul>
               	   	    	<li>10+ user Account</li>
               	   	    	<li>Moneyback Gaurentee</li>
               	   	    	<li>Unlimited Database</li>
               	   	    	<li>24/7 Supports</li>
               	   	    </ul>
               	   </div>
               	   <div class="pricing-button">
               	   	   <a href="#">Purchaces</a>
               	   </div>
               </div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Choose us Area Style Three-->
<!--==================================================-->


<!--==================================================-->
<!-- Start Toptech Brand Area Style Two-->
<!--==================================================-->
<div class="brand-area style-two">
	<div class="container">
		<div class="row">
			<div class="brand-list-1 owl-carousel">
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_1.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_2.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_3.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_5.png" alt="">
						</div>
					</div>
				</div>			
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_6 .png" alt="">
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="single-brand-box">
						<div class="brand-thumb">
							<img src="assets/images/Clients/logo_9  .png" alt="">
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Brand Area Style Two-->
<!--==================================================-->



<!--==================================================-->
<!-- Start Toptech Footer Area Style One-->
<!--==================================================-->
<?php include "footer.php"; ?>
<!--==================================================-->
<!-- End Toptech Footer Area Style One-->
<!--==================================================-->




<!--==================================================-->
<!-- Start Toptech Scroll Up-->
<!--==================================================-->
<div class="prgoress_indicator active-progress">
        <svg class="progress-circle svg-content" width="100%" height="100%" viewBox="-1 -1 102 102">
          <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" style="transition: stroke-dashoffset 10ms linear 0s; stroke-dasharray: 307.919, 307.919; stroke-dashoffset: 212.78;"></path>
        </svg>
 </div>
<!--==================================================-->
<!-- End Toptech Scroll Up-->
<!--==================================================-->

	<!-- jquery js -->
	<script src="assets/js/vendor/jquery-3.6.2.min.js"></script>
	<!-- bootstrap js -->
	<script src="assets/js/bootstrap.min.js"></script>
	<!-- carousel js -->
	<script src="assets/js/owl.carousel.min.js"></script>
	<!-- animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- wow js -->
	<script src="assets/js/wow.js"></script>
	<!-- ajax-mail js -->
	<script src="assets/js/ajax-mail.js"></script>
	<!-- imagesloaded js -->
	<script src="assets/js/imagesloaded.pkgd.min.js"></script>
	<!-- venobox js -->
	<script src="venobox/venobox.js"></script>
	<!--  animated-text js -->
	<script src="assets/js/animated-text.js"></script>
	<!-- venobox min js -->
	<script src="venobox/venobox.min.js"></script>
	<!-- jquery meanmenu js -->
	<script src="assets/js/jquery.meanmenu.js"></script>
	<!-- theme js -->
	<script src="assets/js/theme.js"></script>
	<!-- Cousom carousel js -->
	<script src="assets/js/coustom-carousel.js"></script>
	<script src="assets/js/scroll-up.js"></script>

</body>
</html>