
<!--==================================================-->
<!-- Start Toptech Footer Area Style One-->
<!--==================================================-->
<div class="footer-area style-one">
	<div class="container">
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="footer-logo">
					<a href="index.php"><img src="assets/images/logo-.png" alt=""></a>
				</div>
				<div class="footer-widget-desc">
					<p>Whether starting a new business or revamping an established one, we will make your full scope of digital dreams a reality. With an extensive range of custom services and a carefully curated team of experts, we take your online and offline presence to the next level.</p>
				</div>
				<div class="toptech-button inner-style">
                    <a href="contact.php">More Information<i class="bi bi-arrow-right-short"></i></a>
                </div>
			</div>
			<div class="col-lg-2 col-md-6">
				<div class="footer-widget-content">
					<div class="footer-widget-title">
						<h4>Company</h4>
					</div>
					<div class="footer-widget-menu">
						<ul>
							<li><a href="index.php"><i class="bi bi-arrow-right-circle"></i>Home</a></li>
							<li><a href="about.php"><i class="bi bi-arrow-right-circle"></i>About</a></li>
							<li><a href="service.php"><i class="bi bi-arrow-right-circle"></i>Service</a></li>
							<li><a href="contact.php"><i class="bi bi-arrow-right-circle"></i>Contact</a></li>
						
						</ul>
					</div>
				</div>
			</div>			
			<div class="col-lg-3 col-md-6">
				<div class="footer-widget-content">
					<div class="footer-widget-title">
						<h4>Our Services</h4>
					</div>
					<div class="footer-widget-menu">
						<ul>
							<li><a href="mobile-dev.php"><i class="bi bi-arrow-right-circle"></i>Mobile Application Development</a></li>
							<li><a href="web-dev.php"><i class="bi bi-arrow-right-circle"></i>Web App Development</a></li>
							<li><a href="web-design.php"><i class="bi bi-arrow-right-circle"></i>Website Design</a></li>						
							<li><a href="digital-marketing.php"><i class="bi bi-arrow-right-circle"></i>Digital Marketing Services</a></li>
							<li><a href="seo.php"><i class="bi bi-arrow-right-circle"></i>SEO Marketing</a></li>
							<li><a href="sms.php"><i class="bi bi-arrow-right-circle"></i>Bulk SMS</a></li>
							
						</ul>
					</div>
				</div>
			</div>
		    <div class="col-lg-3 col-md-6">
				<div class="footer-widget-content">
					<div class="footer-widget-title">
						<h4>Newsletter</h4>
					</div>
                    <p class="f-desc-2">Subscribe our Latest Newsletter</p>
                    <form action="#">
                    	<div class="footer-newslatter-box">
                    		<input type="text" name="Email" placeholder="Enter Your E-Mail" required>
                    		<button type="submit">Subscribe</button>
                    	</div>
                    </form>
				</div>
			</div>
		</div>
		<div class="row align-items-center">
			<div class="footer-bottom-area">
				<div class="row">
					<div class="col-lg-6 col-md-6">
						<div class="footer-bottom-content">
							<p>© 2024 <span class="text-primary">Nimatooz</span> Designed By <a href="https://nimatooz.com/" target="_blank"><img class="logo " src="assets/images/footer_nsm.png" alt="NSM-IMG"></a></p>
						</div>
					</div>
					<div class="col-lg-6 col-md-6">
						<div class="footer-botton-social-icon">
							<ul>
								<li><a href="https://www.facebook.com/NimatooZ" rel="noopener" aria-label="facebook" target="_blank" title="facebook"><i class="fa-brands fa-facebook-f"></i></a></li>
								<li><a href="https://twitter.com/SmileMobility" class="d-block" target="_blank"><i class="fa-brands fa-twitter"></i></a></li>
								<li><a href="https://www.linkedin.com/in/nimatooz-smile-mobility-pvt-ltd-086113201/" rel="noopener" aria-label="Linked in" target="_blank" title="linkedin"><i class="fa-brands fa-linkedin-in"></i></a></li>
								<li><a href="#"><i class="fa-brands fa-pinterest-p"></i></a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>
<!--==================================================-->
<!-- End Toptech Footer Area Style One-->
<!--==================================================-->




